package com.example.trans;

public interface config {
String baseurl ="http://192.168.1.4/trans/";
    String imgurl ="http://192.168.1.4/trans/uploads/";
}

